[
{"result": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZEY4qQmwAJhKVFlypt0nZNgzrkApOax6vew&usqp=CAU"},
{"result": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRfyqYAyrxqYswPhrZIfJz_wvS_56-zpPoWqg&usqp=CAU"}
]
